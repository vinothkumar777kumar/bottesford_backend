<?php namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php'))
{
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

$routes->options('(:any)', 'OptionsController::options'); //one options method for all routes.

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'TeamController::index');


	$routes->group('api',['namespace' => 'App\Controllers'],function($routes){
		// authendication
		$routes->post('register','AuthController::userregister');
		$routes->post('userlogin','AuthController::userlogin');
		// get users 
		 $routes->get('user', 'Home::getAllUsers');
		 $routes->get('myaccount/(:any)', 'Home::getUsers/$1');
		 $routes->post('updatemyaccount','Home::updatemyaccount');
		 $routes->post('ticketbooking','TicketController::ticket_booking');
		 $routes->get('getuserticket/(:any)', 'TicketController::get_bookedtickets/$1');
		//  add teams
		$routes->post('addteam','TeamController::addteam');
		$routes->get('getteams', 'TeamController::getallteams');
		$routes->get('editteam/(:any)', 'TeamController::editteamsbyid/$1');
		$routes->post('updateteam','TeamController::updateteam');
		$routes->get('deleteteams/(:any)', 'TeamController::deleteteams/$1');

		// add player
		$routes->post('addplayer','TeamController::addplayer');
		$routes->get('getteamplayers/(:any)', 'TeamController::getteamplayers/$1');
		$routes->get('editteamplayer/(:any)', 'TeamController::editteamplayer/$1');
		$routes->post('updateteamplayer/(:any)','TeamController::updateteamplayer/$1');
		$routes->get('deleteplayerimage/(:any)', 'TeamController::deleteplayerimage/$1');

		// get player
		
		$routes->get('getplayer/(:any)', 'TeamController::editteamplayer/$1');

		//match adding
		$routes->post('addmatch','MatchController::addmatch');
		$routes->get('getallmatch', 'MatchController::getallmatch');
		$routes->get('editmatch/(:any)', 'MatchController::editmatch/$1');
		$routes->get('deletematchimage/(:any)', 'MatchController::deletematchimage/$1');
		$routes->post('updatematch','MatchController::updatematch');
		$routes->get('deletematch/(:any)', 'MatchController::deletematch/$1');

		// not token api

		// user home screen
		$routes->get('nextmatch', 'MatchController::nextmatch');

		// update password users
		$routes->post('updatepassword','Home::update_mypassword');

		// book sports hall
		$routes->post('bookhall','HallbookingController::hallbooking');
		$routes->get('getsportshallbookdata/(:any)', 'HallbookingController::getbooksportsdata/$1');
		$routes->get('get_sportshallbooked', 'HallbookingController::gethallbookeddata');

		// get users list
		$routes->get('users', 'Home::getallusers');

		// booked list api

		$routes->get('getmatchtickets/(:any)', 'TicketController::getTickets/$1');
		$routes->get('todaybookingtickets','TicketController::today_ticket_booking');

		// add match results
		
		$routes->post('addmatchresult','MatchResultController::addmatchresult');
		$routes->get('getallmatchresult', 'MatchResultController::getallmatchresult');
		$routes->get('editmatchresult/(:any)', 'MatchResultController::editmatchresult/$1');
		$routes->get('deletematchresultimage/(:any)', 'MatchResultController::deletematchresultimage/$1');
		$routes->post('updatematchresult','MatchResultController::updatematchresult');
		$routes->get('deletematchresult/(:any)', 'MatchResultController::deletematchresult/$1');

		// GET LAST MATCH RESULT
		$routes->get('getlastmatchresult', 'MatchResultController::getlastmatchresult');

		// get league table data
		$routes->get('getleaguetabledata', 'MatchResultController::getleaguetabledata');
		
		// team manager signup details
		
		$routes->post('managersignup','AuthController::managersignup');
		$routes->get('getdashboardcount/(:any)', 'TeamController::getteamplayerscount/$1');
		$routes->get('getmanagerteamplayers/(:any)', 'TeamController::getallteamplayers/$1');
		$routes->get('getmanagerallmatchdata/(:any)', 'TeamController::getallteammatch/$1');


		// blog 
		
		$routes->get('getallblog', 'BlogController::getallblog');
		$routes->post('addblog','BlogController::addblog');
		$routes->get('editblog/(:any)', 'BlogController::editblog/$1');
		$routes->post('updateblog/(:any)','BlogController::updateblog/$1');
		$routes->get('deleteblog/(:any)', 'BlogController::deletblog/$1');
		$routes->get('deleteblogimage/(:any)', 'BlogController::deleteblogimage/$1');
		 
		 
		 
	});


/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php'))
{
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
